#include "widget.h"
#include "./ui_widget.h"
#include "ImageSwitcher.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    season = 0;//初始设置季节为0,0春 1夏 2秋 3冬
    atmosphere = true;//初始带大气层
    details = 0;//初始细节为0,也就是只显示星星,1为显示连线,2为显示连线+名字
    time = 1000;//一开始在早上
    file_place = "D:\\桌面\\CroppedStarPics\\";



    // 创建 ImageSwitcher 对象
    imageSwitcher = new ImageSwitcher(this,ui->ImageShowStack);

    // 初始化图片
    QVector<QString> imagePaths = {
        "D:\\桌面\\CroppedStarPics\\0101-1000-atmosphere.png",
        "D:\\桌面\\CroppedStarPics\\0101-1000-blank.png",
        "D:\\桌面\\CroppedStarPics\\0101-2200-atmosphere.png",
        "D:\\桌面\\CroppedStarPics\\0101-2200-blank.png",
        "D:\\桌面\\CroppedStarPics\\0101-2200-line.png",
        "D:\\桌面\\CroppedStarPics\\0101-2200-name.png",

        "D:\\桌面\\CroppedStarPics\\0401-1000-atmosphere.png",
        "D:\\桌面\\CroppedStarPics\\0401-1000-blank.png",
        "D:\\桌面\\CroppedStarPics\\0401-2200-atmosphere.png",
        "D:\\桌面\\CroppedStarPics\\0401-2200-blank.png",
        "D:\\桌面\\CroppedStarPics\\0401-2200-line.png",
        "D:\\桌面\\CroppedStarPics\\0401-2200-name.png",

        "D:\\桌面\\CroppedStarPics\\0701-1000-atmosphere.png",
        "D:\\桌面\\CroppedStarPics\\0701-1000-blank.png",
        "D:\\桌面\\CroppedStarPics\\0701-2200-atmosphere.png",
        "D:\\桌面\\CroppedStarPics\\0701-2200-blank.png",
        "D:\\桌面\\CroppedStarPics\\0701-2200-line.png",
        "D:\\桌面\\CroppedStarPics\\0701-2200-name.png",

        "D:\\桌面\\CroppedStarPics\\1001-1000-atmosphere.png",
        "D:\\桌面\\CroppedStarPics\\1001-1000-blank.png",
        "D:\\桌面\\CroppedStarPics\\1001-2200-atmosphere.png",
        "D:\\桌面\\CroppedStarPics\\1001-2200-blank.png",
        "D:\\桌面\\CroppedStarPics\\1001-2200-line.png",
        "D:\\桌面\\CroppedStarPics\\1001-2200-name.png",
        // 继续添加图片路径...
    };
    imageSwitcher->initializeImages(imagePaths);




    /*
    QPixmap pixmap1("D:\\桌面\\CroppedStarPics\\0101-2200-atmosphere.png");
    QPixmap pixmap2("D:\\桌面\\CroppedStarPics\\0101-2200-blank.png");


    qDebug()<<"width,height = ("<<pixmap1.width()<<" "<<pixmap1.height()<<") ("
             <<pixmap2.width()<<" "<<pixmap2.height()<<")";
    */


}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_dial_valueChanged(int value)
{
    season = value;
    imageSwitcher->switchToAppointedImage(getPicName());
    switch(season)
    {
    case 0:
        qDebug()<<"season: Spring(Apr)";
        ui->seasonLabel->setText("更改季节（目前为春季）");
        break;
    case 1:
        qDebug()<<"season: Summer(Jul)";
        ui->seasonLabel->setText("更改季节（目前为夏季）");
        break;
    case 2:
        qDebug()<<"season: Autumn(Oct)";
        ui->seasonLabel->setText("更改季节（目前为秋季）");
        break;
    case 3:
        qDebug()<<"season: Winter(Jan)";
        ui->seasonLabel->setText("更改季节（目前为冬季）");
        break;
    default:
        //理论上不会运行到这里
        qDebug()<<"Error occured when changing season";
    }
}

void Widget::on_atmosphereButton_clicked()
{
    atmosphere = !atmosphere;
    if(atmosphere==true)
    {
        ui->atmosphereButton->setText("把大气层关闭");
        //more...
        imageSwitcher->switchToAppointedImage(getPicName());
    }
    else
    {
        ui->atmosphereButton->setText("把大气层打开");
        //more...
        imageSwitcher->switchToAppointedImage(getPicName());
    }
}


void Widget::on_detailsButton_clicked()
{
    details ++;
    if(details > 2)details = 0;
    imageSwitcher->switchToAppointedImage(getPicName());
    switch(details)
    {
    case 0:
        ui->detailsButton->setText("连线显示星座");
        break;
    case 1:
        ui->detailsButton->setText("连线+名称显示星座");
        break;
    case 2:
        ui->detailsButton->setText("关闭连线显示");
        break;
    default:
        qDebug() << "Error occured when changing details";
    }
}

QString Widget::getPicName()
{
    QString name = file_place;
    switch(season)
    {
    case 0:
        name += "0401";
        break;
    case 1:
        name += "0701";
        break;
    case 2:
        name += "1001";
        break;
    case 3:
        name += "0101";
        break;
    }
    name += "-";
    name += std::to_string(time);
    name += "-";

    //白天的情况
    if(time == 1000){
        if(atmosphere == true)
            name += "atmosphere";
        else
            name += "blank";
    }
    //晚上的情况
    if(time == 2200){
        if(atmosphere == false)
            name += "blank";
        else
        {
            if(details == 0)
                name += "atmosphere";
            if(details == 1)
                name += "line";
            if(details == 2)
                name += "name";
        }
    }


    name += ".png";
    qDebug() << name;
    return name;
}

void Widget::on_timeButton_clicked()
{
    if(time == 1000)
    {
        time = 2200;
        ui->timeButton->setText("将时间调到白天");
    }
    else
    {
        time = 1000;
        ui->timeButton->setText("将时间调到晚上");
    }
    imageSwitcher->switchToAppointedImage(getPicName());
}

