#include "ImageSwitcher.h"
#include <QParallelAnimationGroup>
#include <map>
ImageSwitcher::ImageSwitcher(QWidget *parent,QStackedWidget* UIstack)
    : QWidget(parent), currentIndex(0) {
    stackedWidget = UIstack;

}

void ImageSwitcher::initializeImages(const QVector<QString> &imagePaths) {
    int num = 0;
    for (const QString &path : imagePaths) {
        QLabel *label = new QLabel;
        QPixmap pix(path);
        qDebug()<<stackedWidget->size();
        pix = pix.scaled(stackedWidget->size(),Qt::KeepAspectRatio,Qt::SmoothTransformation);
        label->setPixmap(pix);
        stackedWidget->addWidget(label);
        labels.append(label);
        maploader[path] = num;
        num++;
    }
    stackedWidget->setCurrentWidget(labels[maploader["D:\\桌面\\CroppedStarPics\\0401-1000-atmosphere.png"]]);
}

void ImageSwitcher::switchToNextImage() {
    if (labels.isEmpty()) return;

    int nextIndex = (currentIndex + 1) % labels.size();
    //QLabel *currentLabel = labels[currentIndex];
    QLabel *nextLabel = labels[nextIndex];


    /*
    QPropertyAnimation *fadeOut = createFadeAnimation(currentLabel, 0.0, 0.0, 1000);
    QPropertyAnimation *fadeIn = createFadeAnimation(nextLabel, 0.0, 0.0, 1000);

    // 创建并行动画组
    QParallelAnimationGroup *animationGroup = new QParallelAnimationGroup(this);


    animationGroup->addAnimation(fadeOut);
    animationGroup->addAnimation(fadeIn);

    // 设置动画结束后的信号槽连接
    connect(animationGroup, &QParallelAnimationGroup::finished, this, [=]() {
        stackedWidget->setCurrentWidget(nextLabel);
        qDebug()<<"1";
        nextLabel->setWindowOpacity(0.0); // 重置下一张图片的透明度
        currentIndex = nextIndex;
    });

    // 启动并行动画组
    animationGroup->start();
    */
    stackedWidget->setCurrentWidget(nextLabel);
    qDebug()<<"state change: "<<currentIndex<<" -> "<<nextIndex;
    currentIndex = nextIndex;


}


void ImageSwitcher::switchToAppointedImage(QString str)
{
    if (labels.isEmpty()) return;

    int nextIndex = maploader[str];
    //QLabel *currentLabel = labels[currentIndex];
    QLabel *nextLabel = labels[nextIndex];

    stackedWidget->setCurrentWidget(nextLabel);
    qDebug()<<"state change: "<<currentIndex<<" -> "<<nextIndex;
    currentIndex = nextIndex;
}


QPropertyAnimation* ImageSwitcher::createFadeAnimation(QWidget *widget, qreal startValue, qreal endValue, int duration) {
    QPropertyAnimation *animation = new QPropertyAnimation(widget, "windowOpacity");
    animation->setDuration(duration);
    animation->setStartValue(startValue);
    animation->setEndValue(endValue);
    return animation;
}

void ImageSwitcher::onFadeOutFinished() {
    labels[currentIndex]->setWindowOpacity(1.0);
    currentIndex = (currentIndex + 1) % labels.size();
    stackedWidget->setCurrentIndex(currentIndex);
}

