#ifndef SIMPLEPIXMAPITEM_H
#define SIMPLEPIXMAPITEM_H

#include <QGraphicsPixmapItem>

class SimplePixmapItem : public QGraphicsPixmapItem
{
public:
    SimplePixmapItem(const QPixmap &pixmap)
        : QGraphicsPixmapItem(pixmap) {}
};

#endif // SIMPLEPIXMAPITEM_H
